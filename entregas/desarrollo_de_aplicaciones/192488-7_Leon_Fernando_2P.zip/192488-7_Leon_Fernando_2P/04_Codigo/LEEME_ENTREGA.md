# Entrega local de A*

Fernando León Franco, matrícula 192488-7. MVP del motor documental inmobiliario.

Seguir README.md en esta carpeta. Requisito: Docker Desktop. Copiar .env.example a .env y ejecutar docker compose up --build.

La fuente llama backend/ a la API; esta copia utiliza api/. Dentro del contenedor se conserva /proyecto/backend.

Se incluyen seis contratos ficticios. No se incluyen claves ni .env real. El buscador funciona sin OpenAI.

La exposición es el 4 de noviembre de 2026 a las 17:00, hora de México. El guion y checklist están en docs/.
